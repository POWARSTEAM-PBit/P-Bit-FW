#pragma once
#include "tft_display.h"

// Prototipo para pantallas no implementadas
void draw_placeholder_screen(bool screen_changed, bool data_changed);