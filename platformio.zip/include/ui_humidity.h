#pragma once
#include "tft_display.h"

// 🟢 FIX: Actualizamos el prototipo para aceptar los argumentos
void draw_humidity_screen(bool screen_changed, bool data_changed);