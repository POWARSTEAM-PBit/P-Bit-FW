#pragma once
#include <Arduino.h>

void draw_sound_screen(bool screen_changed, bool data_changed);
void draw_soil_screen(bool screen_changed, bool data_changed);
void draw_ds18_screen(bool screen_changed, bool data_changed);