// ui_timer.h
#pragma once
#include "tft_display.h"

// 🟢 FIX: El prototipo debe aceptar los 3 argumentos
void draw_timer_screen(bool screen_changed, bool data_changed, bool timer_needs_update);