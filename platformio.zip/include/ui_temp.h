#pragma once
#include "tft_display.h"

// 🟢 FIX: Actualizamos el prototipo para aceptar los argumentos de Delta Redraw
void draw_temp_screen(bool screen_changed, bool data_changed);