#pragma once

/**
 * @brief Get the quote of the day
 */
const char * get_qotd();