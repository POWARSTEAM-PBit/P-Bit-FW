#pragma once
#include "tft_display.h"

// Prototipo para la pantalla de Sistema
void draw_system_screen(bool screen_changed, bool data_changed);