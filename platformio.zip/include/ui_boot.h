#pragma once
#include "tft_display.h"

// Prototipo para la pantalla de inicio (Logo)
void run_boot_sequence();